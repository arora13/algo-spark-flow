from flask import Flask, jsonify

application = Flask(__name__)

@application.route('/')
def hello():
    return "Hello World!"

@application.route('/api/health')
def health():
    return jsonify({
        "status": "healthy",
        "message": "AlgoFlow API is running! 🦉"
    })

if __name__ == "__main__":
    application.run(host='0.0.0.0', port=5000)