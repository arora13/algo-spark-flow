from flask import Flask, jsonify
from datetime import datetime

app = Flask(__name__)

@app.route('/')
def health_check():
    return jsonify({
        'status': 'healthy',
        'message': 'AlgoFlow Backend is running!',
        'timestamp': datetime.utcnow().isoformat()
    })

@app.route('/api/test')
def test():
    return jsonify({'message': 'API is working!'})

# WSGI entry point for Elastic Beanstalk
application = app

if __name__ == '__main__':
    app.run(debug=True)