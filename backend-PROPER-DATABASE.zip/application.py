from flask import Flask, request, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from datetime import datetime, timedelta
import os

app = Flask(__name__)

# Configuration - using environment variables for production
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'algoflow-secret-key-for-production-2024')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///algoflow.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY', 'algoflow-jwt-secret-key-for-production-2024')
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(days=7)

# Initialize extensions
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
jwt = JWTManager(app)
CORS(app)  # Allow frontend to talk to backend

# Database Models - where we store all the user data! 🗄️
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # Relationships - users can have progress and activities
    progress = db.relationship('UserProgress', backref='user', lazy=True, uselist=False)
    activities = db.relationship('UserActivity', backref='user', lazy=True)
    
    def __repr__(self):
        return f'<User {self.email}>'

class UserProgress(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    completed_algorithms = db.Column(db.Text, default='[]')  # JSON string of algorithm IDs
    solved_problems = db.Column(db.Text, default='[]')  # JSON string of problem IDs
    total_study_time = db.Column(db.Integer, default=0)  # in minutes
    current_streak = db.Column(db.Integer, default=0)
    longest_streak = db.Column(db.Integer, default=0)
    last_activity = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<UserProgress {self.user_id}>'

class UserActivity(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    activity_type = db.Column(db.String(50), nullable=False)  # 'login', 'problem_solved', 'algorithm_completed'
    activity_data = db.Column(db.Text)  # JSON string with additional data
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<UserActivity {self.user_id}: {self.activity_type}>'

# API Routes - the heart of our backend! ❤️

@app.route('/api/health', methods=['GET'])
def health_check():
    """Simple health check - is our API alive? 💓"""
    return jsonify({
        'status': 'healthy',
        'message': 'AlgoFlow API is running! 🦉',
        'timestamp': datetime.utcnow().isoformat()
    })

@app.route('/api/auth/register', methods=['POST'])
def register():
    """Create a new user account - welcome to the family! 🎉"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data or not data.get('email') or not data.get('password') or not data.get('name'):
            return jsonify({'error': 'Missing required fields'}), 400
        
        email = data['email'].lower().strip()
        password = data['password']
        name = data['name'].strip()
        
        # Check if user already exists
        if User.query.filter_by(email=email).first():
            return jsonify({'error': 'User already exists'}), 409
        
        # Hash password and create user
        password_hash = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User(email=email, name=name, password_hash=password_hash)
        
        db.session.add(user)
        db.session.commit()
        
        # Create progress tracking for new user
        progress = UserProgress(user_id=user.id)
        db.session.add(progress)
        db.session.commit()
        
        # Log registration activity
        activity = UserActivity(
            user_id=user.id,
            activity_type='registration',
            activity_data='{"source": "api"}'
        )
        db.session.add(activity)
        db.session.commit()
        
        return jsonify({
            'message': 'User created successfully',
            'user_id': user.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Registration failed'}), 500

@app.route('/api/auth/login', methods=['POST'])
def login():
    """Log in existing user - welcome back! 👋"""
    try:
        data = request.get_json()
        
        if not data or not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Email and password required'}), 400
        
        email = data['email'].lower().strip()
        password = data['password']
        
        # Find user
        user = User.query.filter_by(email=email).first()
        if not user or not bcrypt.check_password_hash(user.password_hash, password):
            return jsonify({'error': 'Invalid credentials'}), 401
        
        # Update last login
        user.last_login = datetime.utcnow()
        db.session.commit()
        
        # Create JWT token
        access_token = create_access_token(identity=user.id)
        
        # Log login activity
        activity = UserActivity(
            user_id=user.id,
            activity_type='login',
            activity_data='{"source": "api", "timestamp": "' + datetime.utcnow().isoformat() + '"}'
        )
        db.session.add(activity)
        db.session.commit()
        
        return jsonify({
            'access_token': access_token,
            'user': {
                'id': user.id,
                'email': user.email,
                'name': user.name
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Login failed'}), 500

@app.route('/api/user/profile', methods=['GET'])
@jwt_required()
def get_profile():
    """Get user profile - who are you? 👤"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Get user progress
        progress = UserProgress.query.filter_by(user_id=user_id).first()
        
        return jsonify({
            'user': {
                'id': user.id,
                'email': user.email,
                'name': user.name,
                'created_at': user.created_at.isoformat(),
                'last_login': user.last_login.isoformat() if user.last_login else None
            },
            'progress': {
                'completed_algorithms': progress.completed_algorithms if progress else '[]',
                'solved_problems': progress.solved_problems if progress else '[]',
                'total_study_time': progress.total_study_time if progress else 0,
                'current_streak': progress.current_streak if progress else 0,
                'longest_streak': progress.longest_streak if progress else 0
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Failed to get profile'}), 500

@app.route('/api/progress/update', methods=['POST'])
@jwt_required()
def update_progress():
    """Update learning progress - keep growing! 📈"""
    try:
        user_id = get_jwt_identity()
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Get or create user progress
        progress = UserProgress.query.filter_by(user_id=user_id).first()
        if not progress:
            progress = UserProgress(user_id=user_id)
            db.session.add(progress)
        
        # Update progress fields
        if 'completed_algorithms' in data:
            progress.completed_algorithms = data['completed_algorithms']
        if 'solved_problems' in data:
            progress.solved_problems = data['solved_problems']
        if 'total_study_time' in data:
            progress.total_study_time = data['total_study_time']
        if 'current_streak' in data:
            progress.current_streak = data['current_streak']
        if 'longest_streak' in data:
            progress.longest_streak = data['longest_streak']
        
        progress.last_activity = datetime.utcnow()
        
        db.session.commit()
        
        # Log progress update activity
        activity = UserActivity(
            user_id=user_id,
            activity_type='progress_update',
            activity_data=str(data)
        )
        db.session.add(activity)
        db.session.commit()
        
        return jsonify({'message': 'Progress updated successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to update progress'}), 500

@app.route('/api/activities', methods=['GET'])
@jwt_required()
def get_activities():
    """Get user activities - what have you been up to? 📊"""
    try:
        user_id = get_jwt_identity()
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        activities = UserActivity.query.filter_by(user_id=user_id)\
            .order_by(UserActivity.timestamp.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'activities': [{
                'id': activity.id,
                'type': activity.activity_type,
                'data': activity.activity_data,
                'timestamp': activity.timestamp.isoformat()
            } for activity in activities.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': activities.total,
                'pages': activities.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Failed to get activities'}), 500

# Database initialization
def create_tables():
    """Create database tables - the foundation of our app! 🏗️"""
    db.create_all()
    print("Database tables created successfully! 🎉")

# WSGI entry point for Elastic Beanstalk
application = app

if __name__ == '__main__':
    # Development server - for local testing
    app.run(debug=True, host='0.0.0.0', port=5000)