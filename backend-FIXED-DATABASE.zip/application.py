from flask import Flask, request, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from datetime import datetime, timedelta
import os

app = Flask(__name__)

# Configuration - self-contained for AWS deployment
app.config['SECRET_KEY'] = 'algoflow-super-secret-key-2024-production-ready'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///algoflow.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'algoflow-jwt-secret-key-2024-production-ready'
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(days=7)

# Initialize extensions
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
jwt = JWTManager(app)
CORS(app)

# Database Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'created_at': self.created_at.isoformat()
        }

class Problem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    difficulty = db.Column(db.String(20), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    test_cases = db.Column(db.JSON, nullable=False)
    solution = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'difficulty': self.difficulty,
            'category': self.category,
            'test_cases': self.test_cases,
            'solution': self.solution,
            'created_at': self.created_at.isoformat()
        }

class Submission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    problem_id = db.Column(db.Integer, db.ForeignKey('problem.id'), nullable=False)
    code = db.Column(db.Text, nullable=False)
    language = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(20), nullable=False)  # 'accepted', 'failed', 'error'
    test_results = db.Column(db.JSON)
    execution_time = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'problem_id': self.problem_id,
            'code': self.code,
            'language': self.language,
            'status': self.status,
            'test_results': self.test_results,
            'execution_time': self.execution_time,
            'created_at': self.created_at.isoformat()
        }

# Routes
@app.route('/')
def health_check():
    return jsonify({
        'status': 'healthy',
        'message': 'AlgoFlow Backend is running!',
        'timestamp': datetime.utcnow().isoformat()
    })

@app.route('/api/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        
        if not data or not data.get('username') or not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Missing required fields'}), 400
        
        # Check if user already exists
        if User.query.filter_by(username=data['username']).first():
            return jsonify({'error': 'Username already exists'}), 400
        
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'Email already exists'}), 400
        
        # Create new user
        password_hash = bcrypt.generate_password_hash(data['password']).decode('utf-8')
        user = User(
            username=data['username'],
            email=data['email'],
            password_hash=password_hash
        )
        
        db.session.add(user)
        db.session.commit()
        
        # Create access token
        access_token = create_access_token(identity=user.id)
        
        return jsonify({
            'message': 'User created successfully',
            'user': user.to_dict(),
            'access_token': access_token
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        
        if not data or not data.get('username') or not data.get('password'):
            return jsonify({'error': 'Missing username or password'}), 400
        
        user = User.query.filter_by(username=data['username']).first()
        
        if not user or not bcrypt.check_password_hash(user.password_hash, data['password']):
            return jsonify({'error': 'Invalid credentials'}), 401
        
        access_token = create_access_token(identity=user.id)
        
        return jsonify({
            'message': 'Login successful',
            'user': user.to_dict(),
            'access_token': access_token
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/problems', methods=['GET'])
def get_problems():
    try:
        problems = Problem.query.all()
        return jsonify([problem.to_dict() for problem in problems]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/problems/<int:problem_id>', methods=['GET'])
def get_problem(problem_id):
    try:
        problem = Problem.query.get_or_404(problem_id)
        return jsonify(problem.to_dict()), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/submit', methods=['POST'])
@jwt_required()
def submit_solution():
    try:
        data = request.get_json()
        user_id = get_jwt_identity()
        
        if not data or not data.get('problem_id') or not data.get('code') or not data.get('language'):
            return jsonify({'error': 'Missing required fields'}), 400
        
        # Create submission record
        submission = Submission(
            user_id=user_id,
            problem_id=data['problem_id'],
            code=data['code'],
            language=data['language'],
            status='pending'
        )
        
        db.session.add(submission)
        db.session.commit()
        
        # TODO: Implement code execution logic here
        # For now, just return a mock response
        submission.status = 'accepted'
        submission.test_results = {'passed': 3, 'total': 3}
        submission.execution_time = 0.5
        
        db.session.commit()
        
        return jsonify({
            'message': 'Solution submitted successfully',
            'submission': submission.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/submissions', methods=['GET'])
@jwt_required()
def get_submissions():
    try:
        user_id = get_jwt_identity()
        submissions = Submission.query.filter_by(user_id=user_id).order_by(Submission.created_at.desc()).all()
        return jsonify([submission.to_dict() for submission in submissions]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Initialize database tables - FIXED VERSION
def create_tables():
    with app.app_context():
        db.create_all()

# Create tables when the app starts
create_tables()

# WSGI entry point for Elastic Beanstalk
application = app

if __name__ == '__main__':
    app.run(debug=True)